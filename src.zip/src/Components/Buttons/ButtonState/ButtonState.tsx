import React, { useState } from 'react'

export const ButtonState = () => {
    const [text, setText] = useState('Click me!');
    console.log(text);
    return (
        <button onClick={() => setText('Thank you!')}>{text}</button>
    )
}
